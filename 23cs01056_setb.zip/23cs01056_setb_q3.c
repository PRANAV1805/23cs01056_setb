#include<stdio.h>
#include<math.h>
int main()
{
    int x,y,x1,y1,l;
    int r,n;
    
    printf("enter the values");
    scanf("%d %d %d %d %d",&x,&y,&x1,&y1,r);   
    int a;
    a=(x,y);
    int b;
    b=(x1,y1);
    int m;
    m=pow(l,2)== pow((x-x1),2)+pow((y-y1),2);
    n=pow(r,2);
    if(n==m)
    printf("point (%d,%d) lies on the circle",x1,y1);
    else if (n>m)
    printf("point (%d,%d) inside the circle",x1,y1);
    else 
    printf("point (%d,%d) lies outside the circle",x1,y1);
    return 0;


}