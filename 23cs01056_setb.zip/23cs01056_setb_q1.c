#include<stdio.h>
int main()
{
    float h,r,s,v;
     float pi=3.14;
    printf("enter two values");
    scanf("%f %f",&h,&r);  
    s=2*3.14*r*h,v=3.14*r*r*h;
    printf("surface area is %.2f\n",s);
    printf("volume is %.2f\n",v);
    return 0;
}